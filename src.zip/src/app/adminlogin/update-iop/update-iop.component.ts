import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-iop',
  templateUrl: './update-iop.component.html',
  styleUrls: ['./update-iop.component.css']
})
export class UpdateIOPComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
