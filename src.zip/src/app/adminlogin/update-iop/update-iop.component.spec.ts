import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateIOPComponent } from './update-iop.component';

describe('UpdateIOPComponent', () => {
  let component: UpdateIOPComponent;
  let fixture: ComponentFixture<UpdateIOPComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateIOPComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateIOPComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
