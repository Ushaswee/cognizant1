import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AboutComponent } from './about/about.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { AdminComponent } from './admin/admin.component';
import { ImportComponent } from './adminlogin/import/import.component';
import { ManageComponent } from './adminlogin/manage/manage.component';
import { ExchangeComponent } from './adminlogin/exchange/exchange.component';
import { UpdateIOPComponent } from './adminlogin/update-iop/update-iop.component';
import { IPOsComponent } from './userlogin/ipos/ipos.component';
import { CompareCompanyComponent } from './userlogin/compare-company/compare-company.component';
import { CompareSectorsComponent } from './userlogin/compare-sectors/compare-sectors.component';


const routes: Routes = [{path:"login",component:LoginComponent},
{path:"register",component:RegisterComponent},
{path:"about",component:AboutComponent},
{path:"admin",component:AdminComponent},
{path:"adminlogin",component:AdminloginComponent},
{path:"userlogin",component:UserloginComponent},
{path:"import",component:ImportComponent},
{path:"manage",component:ManageComponent},
{path:"exchange",component:ExchangeComponent},
{path:"update-iop",component:UpdateIOPComponent},
{path:"ipos",component:IPOsComponent},
{path:"comparecompany",component:CompareCompanyComponent},
{path:"comaparesectors",component:CompareSectorsComponent},
{path:"other",component:IPOsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

